import { Table } from "antd";
import React from "react";
import { Transaction } from "../../types/transaction";

interface Props {
  transactions: Transaction[];
  loading: boolean;
}

const TransactionsList = ({ transactions, loading }: Props) => {
  const columns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (test, record) => {
        return <span>{record.createdAt.toDate().toDateString()}</span>;
      },
    },
    {
      title: "Type",
      dataIndex: "type",
      key: "type",
    },
    {
      title: "From",
      dataIndex: ["member", "name"],
      key: "memberFullName",
    },
    {
      title: "Category",
      dataIndex: ["category", "name"],
      key: "category",
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description",
    },
    {
      title: "Amount",
      dataIndex: "amount",
      key: "amount",
      // eslint-disable-next-line react/display-name
      render: (text, record) => {
        return record.direction === "in" ? <div style={{ color: "green" }}>{text}</div> : <div>-{text}</div>;
      },
    },
    {
      title: "",
      dataIndex: "status",
      key: "status",
      // eslint-disable-next-line react/display-name
      render: (text, record) => {
        switch (record.status) {
          case 0:
            return  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
            Pending
          </span>
        
          default:
            return null
        }
      },
    },
  ];
  return (
    <Table
      loading={loading}
      rowKey={(record) => record.id}
      columns={columns}
      pagination={{ pageSize: 50 }}
      dataSource={transactions}
    />
  );
};

export default TransactionsList;
