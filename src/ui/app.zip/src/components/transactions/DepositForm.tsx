import { Col, Form, Input, InputNumber, message, Modal, Row } from "antd";
import React from "react";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import { getCurrentPool } from "../../services/pool-service";
import { getCurrentUser } from "../../services/users-service";
import { approveToken, deposit } from "../../services/transactions-services";

const { confirm } = Modal;

interface Props {
  visible: boolean;
  onCreate: (values) => void;
  onCancel: () => void;
}

const DepositForm = ({ visible, onCreate, onCancel }: Props) => {
  const [form] = Form.useForm();

  const handleOk = async() => {
    const formValue = await form.validateFields();
    const pool = await getCurrentPool();
    const user = await getCurrentUser();

    const { amount, description } = formValue;
    try {
      if (!user.pools[pool.id].tokenApproved) {
        await approveToken(pool, user.id);
      }

      await deposit(pool, amount, description);

      
    } catch (e) {
      message.error(e.message);
    }
  };

  const handleCancel = () => {
    if (form)
      confirm({
        title: "Do you Want to leave without saving?",
        icon: <ExclamationCircleOutlined />,
        onOk() {
          form.resetFields();
          onCancel();
        },
      });
  };

  return (
    <Modal
      className="depositForm"
      width={900}
      title="Member Deposit"
      visible={visible}
      onOk={handleOk}
      onCancel={handleCancel}
      destroyOnClose={true}
    >
      <Form name="Deposit" form={form} layout="vertical" initialValues={{}}>
        <Row gutter={16}>
          <Col>
            <Form.Item label="Description:" name="description">
              <Input />
            </Form.Item>
          </Col>
          <Col>
            <Form.Item label="Amount:" name="amount">
              <InputNumber />
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
};

export default DepositForm;
