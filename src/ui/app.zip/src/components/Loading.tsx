import { Spin } from "antd";
import React from "react";

function Loading() {
  return (
    <div className="w-full h-full flex justify-center items-center">
      <Spin></Spin>
    </div>
  );
}

export default Loading;
