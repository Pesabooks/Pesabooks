import { Button, Col, message, Popover, Row, Space } from "antd";
import { useState } from "react";
import { PlusOutlined } from "@ant-design/icons";
import "./PlusMenu.less";
import CreatePoolForm from "../PoolCreateForm";
import { createNewPool } from "../../services/pool-service";
import DepositForm from "../transactions/DepositForm";
import { session } from "../../services/AuthProvider";

export const PlusMenu = () => {
  const [visible, setVisible] = useState(false);

  const [isPoolFormVisible, setIsPoolFormVisible] = useState(false);
  const [isDepositFormVisible, setIsDepositFormVisible] = useState(false);
  const [isWithdrawalFormVisible, setIsWithdrawalFormVisible] = useState(false);
  const [isChargeFormVisible, setIsChargeFormVisible] = useState(false);
  const [isJournalEntryFormVisible, setIsJournalEntryFormVisible] = useState(false);




  const createPool = async (form: any) => {
    try {
      const { name, token } = form;
      await createNewPool(name, token);
      setIsPoolFormVisible(false);
    } catch (e) {
      message.error(e.message);
    }
  };

  const content = (
    <div style={{ padding: "15px" }} className="plusmenu" onClick={() => setVisible(false)}>
      <Row gutter={32}>
        <Col span={12}>
          <Space direction="vertical">
            <Button
              type="text"
              onClick={() => {
                setIsPoolFormVisible(true);
              }}
            >
              New Pool
            </Button>
            <Button
              type="text"
              onClick={() => {
                setIsDepositFormVisible(true);
              }}
            >
              Deposit
            </Button>
            <Button
              type="text"
              onClick={() => {
                setIsWithdrawalFormVisible(true);
              }}
            >
              Withdrawal
            </Button>
            <Button
              type="text"
              onClick={() => {
                setIsChargeFormVisible(true);
              }}
            >
              Charge
            </Button>
          </Space>
        </Col>
      </Row>
    </div>
  );
  return (
    <>
      <Popover
        arrowPointAtCenter={true}
        placement="bottom"
        content={content}
        trigger="click"
        visible={visible}
        onVisibleChange={setVisible}
      >
        <Button style={{ width: "180px" }} type="primary" ghost shape="round" icon={<PlusOutlined />} size="large">
          New
        </Button>
      </Popover>
      {isPoolFormVisible && (
        <CreatePoolForm
          visible={isPoolFormVisible}
          onCreate={createPool}
          onCancel={() => setIsPoolFormVisible(false)}
        ></CreatePoolForm>
      )}
      {isDepositFormVisible && (
        <DepositForm
          visible={isDepositFormVisible}
          onCreate={()=>setIsDepositFormVisible(false)}
          onCancel={() => setIsDepositFormVisible(false)}
        ></DepositForm>
      )}
    </>
  );
};
