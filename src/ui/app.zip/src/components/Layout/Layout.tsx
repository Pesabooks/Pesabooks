import { FunctionComponent, useState } from "react";
import { Avatar, Button, Col, Dropdown, Layout, Menu, Row } from "antd";
import { UserOutlined, DownOutlined } from "@ant-design/icons";
import "./Layout.less";

import Title from "antd/lib/typography/Title";
import { Sidebar } from "./Sidebar";
import { Outlet } from "react-router-dom";
import { session, useAuth } from "../../services/AuthProvider";
import { useDocument } from "../../hooks/useDocument";
import { usersCollection } from "../../services/users-service";
import { doc } from "@firebase/firestore";

const { Header, Content, Footer } = Layout;

const PbLayout: FunctionComponent = () => {
  let auth = useAuth();
  const [user, setUser] = useState(null)
  
  //let [user] = useDocument(doc(usersCollection(), session().userId));
  

  function trucateEthAddress(str) {
    if (!str) return null;
    if (str.length > 30) {
      return str.substr(0, 6) + "..." + str.substr(str.length - 4, str.length);
    }
    return str;
  }

  const menu = (
    <div>
      <div className="flex flex-col">
        <span>{user?.username}</span>
        <span>{trucateEthAddress(user?.id)}</span>
      </div>
      <Menu>
        <Menu.Item key={1}>
          <Button onClick={auth.signout} type="text">
            Log out
          </Button>
        </Menu.Item>
      </Menu>
    </div>
  );

  return (
    <Layout style={{ minHeight: "100vh" }}>
      <Sidebar />
      <Layout className="site-layout">
        <Header className="site-layout-background" style={{ padding: "0 24px" }}>
          <Row>
            <Col flex="none">
              <Title>My pool</Title>
            </Col>
            <Col flex="auto"></Col>

            <Col flex="none">
              <Dropdown overlay={menu} trigger={["click"]}>
                <a className="ant-dropdown-link" onClick={(e) => e.preventDefault()}>
                  <Avatar style={{ color: "#f56a00", backgroundColor: "#fde3cf" }}>{user?.username[0]}</Avatar>
                </a>
              </Dropdown>
            </Col>
          </Row>
        </Header>
        <Content style={{ margin: "0 24px", minHeight: 280 }}>
          <Outlet />
        </Content>
        <Footer style={{ textAlign: "center" }}>Pesapool© 2021</Footer>
      </Layout>
    </Layout>
  );
};

export default PbLayout;
