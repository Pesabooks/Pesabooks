import React, { useEffect, useState } from "react";
import { Checkbox, Col, Form, Input, Modal, Row, Select } from "antd";
import { tokenList } from "../types/token-list";

interface Props {
  visible: boolean;
  onCreate: (values) => void;
  onCancel: () => void;
}

const CreatePoolForm = ({ visible, onCreate, onCancel }: Props) => {
  const [form] = Form.useForm();

  const handleOk = () => {
    form
      .validateFields()
      .then((values) => {
        onCreate(values);
      })
      .catch((info) => {
        console.log("Validate Failed:", info);
      });
  };

  const handleCancel = () => {
    form.resetFields();
    onCancel();
  };

  return (
    <>
      <Modal title="New Pool" visible={visible} onOk={handleOk} onCancel={handleCancel} destroyOnClose={true}>
        <Form name="createPool" form={form} labelCol={{ span: 4 }} wrapperCol={{ span: 14 }}>
          <Form.Item label="Name" name="name">
            <Input />
          </Form.Item>
          <Form.Item label="Token" name="token">
            <Select>
              {tokenList.map((token, index) => {
                return (
                  <Select.Option  value={token.address}  key={token.symbol}>
                    <div className="flex flex-row items-center">
                      <img
                        style={{ width: "20px", height: "20px" }}
                        src={`${process.env.PUBLIC_URL}/${token.image}`}
                        alt="usdc"
                      />
                      <span style={{ marginLeft: "10px" }}>{token.name}</span>
                    </div>
                  </Select.Option>
                );
              })}
            </Select>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default CreatePoolForm;
