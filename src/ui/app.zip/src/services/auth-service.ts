import { User } from "../types/user";
import { firestore } from "../firebase";
import { doc, getDoc } from "firebase/firestore";

export async function getUser(id: string): Promise<User> {
  const docRef = doc(firestore, "users", id);
  const docSnap = await getDoc(docRef);

  const data = docSnap.data as any;

  if (data) {
    return {
      id,
      ...data,
    };
  } else {
    return null;
  }
}
