import { collection, CollectionReference, updateDoc } from "@firebase/firestore";
import { doc, getDoc } from "firebase/firestore";
import { firestore } from "../firebase";
import { User } from "../types/user";
import { session } from "./AuthProvider";

export const usersCollection = () => collection(firestore, "users") as CollectionReference<User>;

export async function getUser(userId: string): Promise<User> {
  const userDoc = await getDoc(doc(usersCollection(), userId));
  return {
    ...userDoc.data(),
    id: userDoc.id,
  } as User;
}

export const getCurrentUser = () => getUser(session().userId);

export function updateUser(id: string, user: Partial<User>) {
  //@ts-ignore
  return updateDoc(doc(usersCollection(), id), user);
}
