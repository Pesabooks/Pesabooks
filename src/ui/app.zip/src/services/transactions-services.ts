import { BigNumber, ContractFactory, ethers } from "ethers";
import { Pool } from "../types/pool";
import { ERC20__factory, Pool__factory } from "@pesapool/smart-contracts";
import { addDoc, collection, CollectionReference, updateDoc } from "@firebase/firestore";
import { firestore } from "../firebase";
import { Transaction } from "../types/transaction";
import { doc } from "firebase/firestore";
import { getCurrentUser, usersCollection } from "./users-service";

export const transationsCollection = (poolId) =>
  collection(firestore, "pools", poolId, "transactions") as CollectionReference<Transaction>;

export async function deposit(pool: Pool, amount: number, description: string) {
  
  const user = await getCurrentUser();
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = provider.getSigner(user.id);

  const poolContract = Pool__factory.connect(pool.contractAddress, signer);

  const tx = await poolContract.deposit((await user).id, BigNumber.from(amount));

  const transaction: Transaction = {
    amount: amount,
    description: description || "",
    user: {
      id: user.id,
      username: user.username,
    },
    createdAt: new Date(),
    type: "deposit",
    category: { id: "1", name: "Cotisation" },
    hash: tx.hash,
    from: tx.from,
    to: tx.to,
    status:0,
    direction:"in"
  };

  //Save pending transaction
  const transactionDoc = await addDoc(transationsCollection(pool.id), transaction);

  //wait for transaction in the backgroup
  tx.wait(1).then(async (receipt) => {
    let tx = await provider.getTransaction(receipt.transactionHash);
    if (tx.blockNumber) {
      if (tx.timestamp) transaction.timestamp = tx.timestamp;

      const txRef = doc(transationsCollection(pool.id), transactionDoc.id);
      updateDoc(txRef, { status: 1 });
    }
  });
}

export async function approveToken(pool: Pool, userId) {
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = provider.getSigner(userId);

  const tokenContract = ContractFactory.getContract(pool.token.address, ERC20__factory.abi, signer);

  await (await tokenContract.increaseAllowance(pool.contractAddress, BigNumber.from(2 ^ (256 - 1)))).wait();

  const userRef = doc(usersCollection(), userId);
  //@ts-ignore
  await updateDoc(userRef, { [`pools.${pool.id}.tokenApproved`]: true });
}
