import {
  addDoc,
  collection,
  CollectionReference,
  doc,
  writeBatch,
} from "@firebase/firestore";
import { Pool__factory } from "@pesapool/smart-contracts";
import { ContractFactory, ethers } from "ethers";
import { getDoc } from "firebase/firestore";
import { firestore } from "../firebase";
import { Pool } from "../types/pool";
import { Role } from "../types/role";
import { tokenList } from "../types/token-list";
import { session } from "./AuthProvider";
import { usersCollection } from "./users-service";

export const poolsCollection = () => collection(firestore, "pools") as CollectionReference<Pool>;

export const createNewPool = async (name: string, tokenAddress: string) => {
  // create smart contract
  const userId = session().userId;
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = provider.getSigner(userId);

  const factory = new ContractFactory(Pool__factory.abi, Pool__factory.bytecode, signer);
  const contract = await factory.deploy(tokenAddress);

  const newPool: Pool = {
    name,
    token: tokenList.find((t) => t.address === tokenAddress),
    contractAddress: contract.address,
  };
  var poolRef = await addDoc(poolsCollection(), newPool);
  await addUserToPool(poolRef.id, userId, Role.admin, true);
};

function addUserToPool(poolId: string, userId: string, role: Role, isOwner = false): Promise<void> {
  // Get a new write batch
  const batch = writeBatch(firestore);

  const userRef = doc(usersCollection(), userId);
  const poolRef = doc(poolsCollection(), poolId);

  const userPoolRole = {
    isMember: true,
    isOwner: isOwner,
    role: role,
  };

  //@ts-ignore
  batch.update(userRef, { lastPoolId: poolId, [`pools.${poolId}`]: userPoolRole });
  //@ts-ignore
  batch.update(poolRef, { [`users.${userId}`]: userPoolRole });

  return batch.commit();
}

export async function getContractBalance(pool: Pool) {
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const contract = await Pool__factory.connect(pool.contractAddress, provider);
  const balance = await contract.balance();

  return balance.toNumber();
}

export async function getCurrentPool(): Promise<Pool> {
  const poolDoc = await getDoc(doc(poolsCollection(), session().poolId));
  return {
    ...poolDoc.data(),
    id: poolDoc.id,
  } as Pool;
}
