import React, { useEffect, useState } from "react";

import { onAuthStateChanged, signInWithCustomToken, User as FirebaseUser } from "firebase/auth";
import { firebaseAuth, firebaseFunc } from "../firebase";
import { Navigate, useLocation, useNavigate } from "react-router";
import { ethers } from "ethers";
import { httpsCallable } from "firebase/functions";
import Loading from "../components/Loading";
import { getDoc, updateDoc } from "@firebase/firestore";
import { usersCollection } from "./users-service";
import { doc } from "firebase/firestore";
import { User } from "../types/user";

const USER_ID_SESSION = "user_id";
const POOL_ID_SESSION = "pool_id";

type AuthContextType = {
  user: FirebaseUser | null;
  authenticated: boolean;
  signout: () => void;
  signInWithMetamask: (signer: ethers.providers.JsonRpcSigner) => Promise<boolean>;
  loadingAuthState: boolean;
};

export const AuthContext = React.createContext<Partial<AuthContextType>>({});

export const AuthProvider = ({ children }: any) => {
  const [user, setUser] = useState(null as FirebaseUser | null);
  const [loadingAuthState, setLoadingAuthState] = useState(true);
  let navigate = useNavigate();

  let signout = () => {
    firebaseAuth.signOut().then(() => {
      setUser(null);
      navigate("/login");
      sessionStorage.removeItem(USER_ID_SESSION);
    });
  };

  let signInWithMetamask = async (signer: ethers.providers.JsonRpcSigner): Promise<boolean> => {
    const getNonceToSign = httpsCallable<{ address: string }, { nonce: string; isNewUser: boolean }>(
      firebaseFunc,
      "getNonceToSign"
    );
    const getNonceToSignResult = await getNonceToSign({ address: signer._address });

    // Get the user to sign the nonce with their private key
    const signature = await signer.signMessage(getNonceToSignResult.data.nonce);

    //If the signature is valid, retrieve a custom auth token for Firebase
    const verifySignedMessage = httpsCallable<{ address: string; signature: string }, { token: string }>(
      firebaseFunc,
      "verifySignedMessage"
    );
    const verifySignedMessageResult = await verifySignedMessage({ address: signer._address, signature });

    await signInWithCustomToken(firebaseAuth, verifySignedMessageResult.data.token);

    return getNonceToSignResult.data.isNewUser;
  };

  useEffect(() => {
    onAuthStateChanged(firebaseAuth, (user) => {
      setUser(user);
      setLoadingAuthState(false);
      if (user?.uid) {
        sessionStorage.setItem(USER_ID_SESSION, user.uid);
      }
    });
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        authenticated: user !== null,
        signout,
        signInWithMetamask,
        loadingAuthState,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  return React.useContext(AuthContext);
}

export function RequireAuth({ children }: { children: JSX.Element }) {
  let auth = useAuth();
  let location = useLocation();

  if (auth.loadingAuthState) {
    return <Loading></Loading>;
  } else if (!auth.user) {
    // Redirect them to the /login page, but save the current location they were
    // trying to go to when they were redirected. This allows us to send them
    // along to that page after they login, which is a nicer user experience
    // than dropping them off on the home page.
    return <Navigate to="/login" state={{ from: location }} />;
  }

  return children;
}

export function session() {
  return {
    userId: sessionStorage.getItem(USER_ID_SESSION),
    poolId: sessionStorage.getItem(POOL_ID_SESSION),
  };
}

export function RequirePool({ children }: { children: JSX.Element }) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const userRef = doc(usersCollection(), session().userId);

    getDoc(userRef).then((ref) => {
      const user: User = ref.data();

      if (user.lastPoolId) {
        sessionStorage.setItem(POOL_ID_SESSION, user.lastPoolId);
      } else if (user.pools) {
        var keys = Object.keys(user.pools);
        if (keys.length > 0) {
          const poolId = keys[0];
          sessionStorage.setItem(POOL_ID_SESSION, poolId);
          updateDoc(userRef, { lastPoolId: poolId }).then();
        }
      }
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <Loading></Loading>;
  } else if (!session().poolId) {
    return <Navigate to="/new-pool" />;
  }

  return children;
}
