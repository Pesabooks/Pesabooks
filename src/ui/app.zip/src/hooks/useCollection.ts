import { CollectionReference, onSnapshot, query, Query } from "@firebase/firestore";
import { useState, useEffect } from "react";


export function useCollection<T>(collectionRef: CollectionReference<T>): [data: T[], loading: boolean, error:any] {
  const [data, setData] = useState<T[]>(null);
  const [error, setError] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const handleError = (e: any) => {
    setData(null);
    setError(e);
    setLoading(false);
  };

  useEffect(() => {
    try {
     const q = query(collectionRef);
      const unSubscribe = onSnapshot(
        q,
        (querySnapshot) => {
          setData(
            querySnapshot.docs.map((doc) => {
              const val = { ...doc.data(), id: doc.id };
              return val;
            })
          );
          setError(null);
          setLoading(false);
          const cities = [];
          querySnapshot.forEach((doc) => {
            cities.push(doc.data());
          });
        },
        handleError
      );

      return unSubscribe; // clean up
    } catch (e) {
      handleError(e);
      return () => {};
    }
  }, [collectionRef.path]);

  return [data, loading, error];
}
