import { onSnapshot } from "@firebase/firestore";
import { DocumentReference } from "firebase/firestore";
import { useState, useEffect } from "react";

export function useDocument<T>(ref: DocumentReference<T>): [data: T, loading: boolean, error: any] {
  const [data, setData] = useState<T>(null);
  const [error, setError] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const handleError = (e: any) => {
    setData(null);
    setError(e);
    setLoading(false);
  };

  useEffect(() => {
    try {
      const unSubscribe = onSnapshot(
        ref,
        (doc) => {
          setData({ ...doc.data(), id: doc.id });
          setError(null);
          setLoading(false);
        },
        handleError
      );
      return unSubscribe; // clean up
    } catch (e) {
      handleError(e);
      return () => {};
    }
  }, [ref.path]);

  return [data, loading, error];
}
