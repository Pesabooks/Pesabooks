import { Button, Card, Spin } from "antd";
import { ethers } from "ethers";
import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "../services/AuthProvider";
import "./Signin.css";

function Signin() {
  let navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  let auth = useAuth();

  let signin = async () => {
    try {
      // request access to the user's MetaMask account
      const [account] = await window.ethereum.request({ method: "eth_requestAccounts" });

      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner(account);

      setLoading(true);
      const isNewUser = await auth.signInWithMetamask(signer);
      if (true) {
        navigate("/register");
      } else navigate("/");
    } catch (error) {
      setLoading(false);
    }
  };
  return (
    <div
      style={{ background: `url('${process.env.PUBLIC_URL}/bg.jpg') no-repeat center`, backgroundSize: "cover" }}
      className="w-full h-screen flex justify-center items-center"
    >
      <Spin spinning={loading}>
        <Card title="Pesapool" bordered={true} style={{ width: 300 }}>
          <p>
            <Button type="primary" onClick={() => signin()}>
              Sign in with Metamaks
            </Button>
          </p>
        </Card>
      </Spin>
    </div>
  );
}

export default Signin;
