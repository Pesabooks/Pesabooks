import React from "react";
import { Button, Card, Form, Input, Layout, message, Select } from "antd";
import { Header, Content, Footer } from "antd/lib/layout/layout";
import { useNavigate } from "react-router";
import { createNewPool } from "../services/pool-service";
import { tokenList } from "../types/token-list";

function CreatePool() {
  const [form] = Form.useForm();
  const navigate = useNavigate();

  const createPool = async () => {
    const values = await form.validateFields();
    try {
      try {
        const { name, token } = values;
        await createNewPool(name, token);
        navigate("/");
      } catch (e) {
        message.error(e.message);
      }
    } catch (info) {
      console.log("Validate Failed:", info);
    }
  };

  return (
    <Layout style={{ minHeight: "100vh" }}>
      <Header>header</Header>
      <Layout>
        <Content className="w-full h-full flex justify-center items-center">
          <Card title="Create a new pool" bordered={false} style={{width:'600px'}}> 
            <Form name="createPool" form={form} labelCol={{ span: 4 }} wrapperCol={{ span: 14 }}>
              <Form.Item label="Name" name="name">
                <Input />
              </Form.Item>
              <Form.Item label="Token" name="token">
                <Select>
                  {tokenList.map((token, index) => {
                    return (
                      <Select.Option value={token.address} key={token.symbol}>
                        <div className="flex flex-row items-center">
                          <img
                            style={{ width: "20px", height: "20px" }}
                            src={`${process.env.PUBLIC_URL}/${token.image}`}
                            alt="usdc"
                          />
                          <span style={{ marginLeft: "10px" }}>{token.name}</span>
                        </div>
                      </Select.Option>
                    );
                  })}
                </Select>
              </Form.Item>
            </Form>
            <Button type="primary" onClick={() => createPool()}>
              Create Pool
            </Button>
          </Card>
        </Content>
      </Layout>
      <Footer style={{ textAlign: "center" }}>Pesapool© 2021</Footer>
    </Layout>
  );
}

export default CreatePool;
