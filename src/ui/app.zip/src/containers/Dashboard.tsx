import { PageHeader, Card, Statistic, Button } from "antd";
import { useEffect, useState } from "react";
import { getContractBalance, poolsCollection } from "../services/pool-service";
import { useCollection } from "../hooks/useCollection";
import { session, useAuth } from "../services/AuthProvider";
import { transationsCollection } from "../services/transactions-services";
import TransactionsList from "../components/transactions/TransactionsList";
import { Transaction } from "../types/transaction";
import { doc } from "firebase/firestore";
import { useDocument } from "../hooks/useDocument";
import DepositForm from "../components/transactions/DepositForm";
import { ethers } from "ethers";

function Dashboard() {
  const [balance, setBalance] = useState(0);
  const [isDepositFormVisible, setIsDepositFormVisible] = useState(false);

  const [transactions, loading] = useCollection<Transaction>(transationsCollection(session().poolId));
  const [pool] = useDocument(doc(poolsCollection(), session().poolId));
  const auth = useAuth()

  const connectWallet = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
    // Prompt user for account connections
    await provider.send("eth_requestAccounts", []);
    const signer = provider.getSigner(auth.user.uid);
  };

  useEffect(() => {
    if (pool) getContractBalance(pool).then((balance) => setBalance(balance));
  }, []);

  return (
    <>
      <PageHeader
        backIcon={false}
        title="Dashboard"
        subTitle=""
        extra={[
          <Button key="1" type="primary" onClick={() => setIsDepositFormVisible(true)}>
            Deposit
          </Button>,
          <Button key="2" type="primary">
            Withdraw
          </Button>,
          <Button key="1" type="primary" onClick={() => connectWallet()}>
            Connect Wallet
          </Button>,
        ]}
      />
      <div className="flex flex-row gap-16">
        <Card className="flex-1">
          <Statistic title="Balance" value={balance} precision={2} valueStyle={{ color: "#3f8600" }} suffix="$" />
        </Card>

        <Card className="flex-1">
          <Statistic title="Loan" value={3000} precision={2} suffix="$" />
        </Card>

        <Card className="flex-1">
          <Statistic title="Savings" value={12000} precision={2} suffix="$" />
        </Card>
      </div>
      <div className="mt-8">
        <Card title="Transactions">
          <TransactionsList transactions={transactions} loading={loading}></TransactionsList>
        </Card>
      </div>
      <DepositForm
        visible={isDepositFormVisible}
        onCreate={() => setIsDepositFormVisible(false)}
        onCancel={() => setIsDepositFormVisible(false)}
      ></DepositForm>
    </>
  );
}

export default Dashboard;
