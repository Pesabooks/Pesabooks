import { Button, Card, Col, Form, Input, Row, Spin } from "antd";
import { useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "../services/AuthProvider";
import { updateUser } from "../services/users-service";

function Register() {
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  let auth = useAuth();

  let register = async () => {
    try {
      setLoading(true);
      const formValue = await form.validateFields();
      await updateUser(auth.user.uid, { username: formValue.userName });
      navigate("/");
    } catch (error) {
      setLoading(false);
    }
  };
  return (
    <div
      style={{ background: `url('${process.env.PUBLIC_URL}/bg.jpg') no-repeat center`, backgroundSize: "cover" }}
      className="w-full h-screen flex justify-center items-center"
    >
      <Spin spinning={loading}>
        <Card title="Create an account" bordered={true} style={{ width: 300 }}>
          <div>
            <Form name="register" form={form} layout="vertical" initialValues={{}}>
              <Row gutter={16}>
                <Col>
                  <Form.Item label="Username:" name="userName">
                    <Input />
                  </Form.Item>
                </Col>
              </Row>
            </Form>
            <Button type="primary" onClick={() => register()}>
              Continue
            </Button>
          </div>
        </Card>
      </Spin>
    </div>
  );
}

export default Register;
