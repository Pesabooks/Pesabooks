import "./App.less";

import { BrowserRouter, Route, Routes } from "react-router-dom";
import Dashboard from "./containers/Dashboard";
import Signin from "./containers/Signin";
import PbLayout from "./components/Layout/Layout";
import { AuthProvider, RequireAuth, RequirePool } from "./services/AuthProvider";
import CreatePool from "./containers/CreatePool";
import Register from "./containers/Register";

function App() {
  return (
    <main>
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<Signin />} />
            <Route
              path="/register"
              element={
                <RequireAuth>
                  <Register />
                </RequireAuth>
              }
            />
            <Route
              path="new-pool"
              element={
                <RequireAuth>
                  <CreatePool />
                </RequireAuth>
              }
            />

            <Route path="/" element={<PbLayout />}>
              <Route
                path=""
                element={
                  <RequireAuth>
                    <RequirePool>
                      <Dashboard />
                    </RequirePool>
                  </RequireAuth>
                }
              />
            </Route>
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </main>
  );
}

export default App;
