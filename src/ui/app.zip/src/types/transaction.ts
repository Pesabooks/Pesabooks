export interface Transaction {
  type: TransactionType;
  from: string;
  to: string;
  user: {
    id: string;
    username: string;
  };
  timestamp?: number;
  dueDate?: any;
  category: {
    id: string;
    name: string;
  };
  amount: number;
  description?: string;
  hash: string;
  createdAt: any;
  status: number;
  direction: "in" | "out";
}

export type TransactionType = "deposit" | "transfer" | "payment";
