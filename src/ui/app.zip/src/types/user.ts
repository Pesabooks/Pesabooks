import { Doc } from "./doc";
import { Role } from "./role";

export interface User extends Doc {
  username?: string;
  email?: string;
  isHost?: boolean;
  pictureUrl?: string;
  phoneNumber?: string;
  lastPoolId?: string;
  pools?: {
    [poolId: string]: {
      isMember: boolean;
      isOwner: boolean;
      role: Role;
      tokenApproved: boolean;
    };
  };
}
