import { TransactionType } from "./transaction";

export interface Category {
  id?: string;
  name?: string;
  description?: string;
  type?: TransactionType;
  color?: string;
  active?: boolean;
}
