export interface Token {
  address: string;
  symbol: string;
  name: string;
  image: string;
}
