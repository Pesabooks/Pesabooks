export interface Doc {
  id?: string;
  createdAt?: Date | any;
  createdBy?: DocRef;
  modifiedAt?: Date | any;
  modifiedBy?: DocRef;
}
export interface DocRef {
  id: string;
  name: string;
}
