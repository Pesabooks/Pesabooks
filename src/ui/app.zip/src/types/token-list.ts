import { Token } from "./Token";

export const tokenList: Token[] = [
  {
    address: "0x5fc8d32690cc91d4c39d9d3abcbd16989f875707",
    symbol: "musdt",
    name: "Mock Tether",
    image: "images/token/usdt.png",
  },
  {
    address: "string",
    symbol: "usdc",
    name: "USD Coin",
    image: "images/token/usdc.png",
  },
  {
    address: "string",
    symbol: "usdt",
    name: "Tether",
    image: "images/token/usdt.png",
  },
  {
    address: "dai.tokens.ethers.eth",
    symbol: "dai",
    name: "DAI",
    image: "images/token/dai.png",
  },
  {
    address: "TrueCAD",
    symbol: "tcad",
    name: "TrueCAD",
    image: "images/token/tcad.png",
  },
  {
    address: "string",
    symbol: "eur",
    name: "Statis Euro",
    image: "images/token/eurs.png",
  },
];
