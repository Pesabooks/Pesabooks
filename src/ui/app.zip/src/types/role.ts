export enum Role {
    admin = 'admin',
    member = 'member'
  }
  