
import { Doc } from "./doc";
import { Role } from "./role";
import { Token } from "./Token";

export interface Pool extends Doc{
  name: string;
  description?: string;
  token: Token;
  tokenApproval?: {
    [userId: string]: {
      status: "none" | "pending" | "approved";
    };
  };
  contractAddress: string;
  users?: {
    [userId: string]: {
      isMember: boolean;
      isOwner: boolean;
      role: Role;
    };
  };
}
