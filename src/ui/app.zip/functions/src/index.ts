import * as admin from "firebase-admin";

admin.initializeApp();

export { getNonceToSign } from "./auth/getNonceToSign";
export { verifySignedMessage } from "./auth/verifySignedMessage";
