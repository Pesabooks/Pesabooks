import * as functions from "firebase-functions";
import * as admin from "firebase-admin";

export const getNonceToSign = functions.https.onCall(async ({ address }) => {
  if (!address) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "address is missing",
    );
  }
  // Get the user document for that address
  const userDoc = await admin
    .firestore()
    .collection("users")
    .doc(address)
    .get();

  if (userDoc.exists) {
    const existingNonce = userDoc.data()?.nonce;
    return { nonce: existingNonce, isNewUser: false };
  } else {
    const generatedNonce = Math.floor(Math.random() * 1000000).toString();

    const createdUser = await admin.auth().createUser({
      uid: address,
    });
    // Associate the nonce with that user
    await admin.firestore().collection("users").doc(createdUser.uid).set({
      nonce: generatedNonce,
    });
    return { nonce: generatedNonce, isNewUser: true };
  }
});
