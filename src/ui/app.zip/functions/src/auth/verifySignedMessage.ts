import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import { recoverPersonalSignature } from "@metamask/eth-sig-util";

export const verifySignedMessage = functions.https.onCall(
  async ({ address, signature }) => {
    try {
      if (!address || !signature) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "address or signature are  missing",
        );
      }

      const userDocRef = admin.firestore().collection("users").doc(address);
      const userDoc = await userDocRef.get();

      if (userDoc.exists) {
        const existingNonce = userDoc.data()?.nonce;

        // Recover the address of the account used to create the given Ethereum signature.
        const recoveredAddress = recoverPersonalSignature({
          data: existingNonce,
          signature: signature,
        });

        if (
          recoveredAddress.toLocaleLowerCase() === address.toLocaleLowerCase()
        ) {
          //  update the nonce to prevent replay attacks
          await userDocRef.update({
            nonce: Math.floor(Math.random() * 1000000).toString(),
          });

          const firebaseToken = await admin.auth().createCustomToken(address);

          return { token: firebaseToken };
        } else {
          throw new functions.https.HttpsError(
            "invalid-argument",
            "The signature could not be verified",
          );
        }
      } else {
        throw new functions.https.HttpsError(
          "not-found",
          "user does not exist",
        );
      }
    } catch (err) {
      console.error(err);
      throw new functions.https.HttpsError("unknown", "", err);
    }
  },
);
