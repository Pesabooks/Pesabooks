export const Const = {
  UsersCollection: "users",
  PoolsCollection: "pools",
  TransactionsCollection: "transactions",
  CategoriesCollection: "categories",
};
